/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package doanjava;

import java.sql.SQLException;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author admin
 */
public class chitietphieunhapbus {
 public static   ArrayList<chitietphieunhapdto>  dsctpn  =null ;
 
 public List loaddata() throws SQLException
 {  
     if(dsctpn==null){
       dsctpn= new ArrayList<chitietphieunhapdto>();
       dsctpn.addAll(new chitietphieunhapdao().loaddata());
       return dsctpn;
 }
     else{
     
     return dsctpn;
     }
 }
         
 public int them(chitietphieunhapdto ct)
 {
     if(dsctpn!=null){
         
         for(int i=0;i<dsctpn.size();i++)
         {
             if(dsctpn.get(i).maphieu==ct.maphieu)
             {   return 0;
            
             }
             
         }
         dsctpn.add(ct);
         new chitietphieunhapdao().them(ct);
         return 1;
     }
     else{
         dsctpn=new ArrayList<>();
         dsctpn.add(ct);
     new chitietphieunhapdao().them(ct);
     return 1;
     }
    
  }
 public chitietphieunhapdto timkiem(int ma)
 {
 
 if(dsctpn==null){return null;}
 for(int i=0;i<dsctpn.size();i++)
     
 {
 
 if(dsctpn.get(i).maphieu==ma)
 {
     return dsctpn.get(i);
 }
 }
 return null;
 }
 
 
 
 }
    

