/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package doanjava;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

/**
 *
 * @author admin
 */
public class chitietphieunhapdao {
    
    public List loaddata() throws SQLException
    {
    String sql="SELECT * FROM `chitietphieunhap`";
    ResultSet rs=new connect().taoketnoi().executeQuery(sql);
        if(!rs.last())
        {
        return null;
        }else
        {  Vector vt=new Vector();
        List ds=new ArrayList();
        while(rs.next())
        {
            vt.add(rs.getInt(1));
            vt.add(rs.getInt(2));
            vt.add(rs.getInt(3));
            vt.add(rs.getInt(4));
            vt.add(rs.getInt(5));
            ds.add(vt);
        }
        return ds;
        }
        
        
        }
    
    public void them(chitietphieunhapdto ct)
    { String sql="INSERT INTO `chitiethoadon`(`id_hoa_don`, `id_san_pham`, `so_luong`, `don_gia`, `thanh_tien`) VALUES ("
            +ct.maphieu+","+ct.masp+","+ct.dongia+","+ct.soluong+","+ct.dongia*ct.soluong+")";
        try{
     new connect().taoketnoi().execute(sql);
        }
        catch(Exception e)
        {
        System.err.print(e);
        }
        
    }
    }
    
    
