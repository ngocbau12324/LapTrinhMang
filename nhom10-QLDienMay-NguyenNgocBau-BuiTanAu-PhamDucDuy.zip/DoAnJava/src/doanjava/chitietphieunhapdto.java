/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package doanjava;

/**
 *
 * @author admin
 */
public class chitietphieunhapdto {
    int maphieu;
    int masp;
    int soluong;
    int dongia;
    int thanhtien;
    
}
