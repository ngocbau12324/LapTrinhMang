/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package doanjava;

import java.util.Date;

/**
 *
 * @author admin
 */
public class phieunhapdto {
  int maphieu;
   int manv;
   int mancc;
   Double tongtien;
   String ngaynhap;
    
    
}
